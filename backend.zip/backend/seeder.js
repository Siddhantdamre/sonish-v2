import mongoose from 'mongoose';
import dotenv from 'dotenv';
import users from './data/users.js';
import products from './data/products.js';
import User from './models/userModel.js';
import Product from './models/productModel.js';
import Order from './models/orderModel.js';

dotenv.config();

const importData = async () => {
  try {
    if (!process.env.MONGO_URI) {
      console.warn('⚠️  MONGO_URI not set. Skipping seed.');
      process.exit();
    }

    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅  MongoDB connected for seeding');

    // Wipe existing data
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    // Import users
    const createdUsers = await User.insertMany(users);
    const adminUser = createdUsers[0]._id;

    // Attribute products to admin user
    const sampleProducts = products.map((product) => {
      return { ...product, user: adminUser };
    });

    await Product.insertMany(sampleProducts);

    console.log('✅  Data Imported!');
    process.exit();
  } catch (error) {
    console.error(`❌  Seed Error: ${error.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    console.log('✅  Data Destroyed!');
    process.exit();
  } catch (error) {
    console.error(`❌  Seed Error: ${error.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
